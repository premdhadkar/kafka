package streams;

public class PageView {
    public String userid;
    public Long viewtime;
    public String pageid;
}
