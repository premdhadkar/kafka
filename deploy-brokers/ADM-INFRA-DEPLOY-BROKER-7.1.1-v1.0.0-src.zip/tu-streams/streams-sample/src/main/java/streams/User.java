package streams;

public class User {
    public String userid;
    public Long registertime;
    public String regionid;
    public String gender;
}